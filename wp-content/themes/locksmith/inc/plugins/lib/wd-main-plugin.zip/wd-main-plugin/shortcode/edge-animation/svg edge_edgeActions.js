
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",33000,function(sym,e){sym.play()});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",63000,function(sym,e){sym.play(0)});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",63000,function(sym,e){sym.play(0)});
//Edge binding end
})("stage");
//Edge symbol end:'stage'
})(jQuery,AdobeEdge,"EDGE-152523965");
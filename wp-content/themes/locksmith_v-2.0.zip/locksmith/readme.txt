  Theme Name: Locksmith
  Theme URI: http://themes.webdevia.com/locksmith/
  Description: Locksmith company WordPress theme
  Author: Mymoun
  Author URI: http://www.webdevia.com/
  Version: 1.0
  Text Domain: locksmith
  Domain Path: /languages
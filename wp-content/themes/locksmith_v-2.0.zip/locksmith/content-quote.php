<article class="post">
	<div class="quote-format">
		<blockquote>
			<span class="leftq quotes">&quot;</span>

			<?php the_content() ?>
			<span class="rightq quotes">&#8222; </span>

			<h2>-<?php the_title() ?></h2>

			<div class="share-post">
				<span class="left"><i class="fa fa-share-alt"></i></span>

				<div data-title="&lt;i class='fa fa-twitter'&gt;&lt;/i&gt;" data-text="Helen Keller"
				data-url="#" class="twitter-share left sharrre">
					<div class="box">
						<a href="#" class="count">0</a><a href="#" class="share"><i
						class="fa fa-twitter"></i></a>
					</div>
				</div>
				<div data-title="&lt;i class='fa fa-facebook'&gt;&lt;/i&gt;" data-text="Helen Keller"
				data-url="#" class="facebook-share left sharrre">
					<div class="box">
						<a href="#" class="count">0</a><a href="#" class="share"><i
						class="fa fa-facebook"></i></a>
					</div>
				</div>
			</div>
		</blockquote>
	</div>
</article>
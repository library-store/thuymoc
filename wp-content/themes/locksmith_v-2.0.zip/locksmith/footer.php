

	<section class="wd-footer">
<?php if(is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3')) { ?>
		<div class="row animation-parent" data-animation-delay="180">

					<?php
						  $locksmith_footer_columns = locksmith_get_option('locksmith_footer_columns','three _columns');
						  switch ($locksmith_footer_columns) {
							  case "one_columns":
								  $column_one = 12;
								  break;
							  case "tow_a_columns":
								  $column_one = 4;
								  $column_tow = 8;
								  break;
							  case "tow_b_columns":
								  $column_one = 8;
								  $column_tow = 4;
								  break;
							  case "tow_c_columns":
								  $column_one = 6;
								  $column_tow = 6;
								  break;
							  default:
								  $column_one = 4;
								  $column_tow = 4;
								  $column_three = 4;
						  } ?>

	            <ul class="block large-<?php echo esc_attr($column_one) ?> medium-<?php echo esc_attr($column_one) ?> columns animated" data-animated="fadeInRight">
	               <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-1') ) : ?><?php endif; ?>
	            </ul>

						  <?php if($locksmith_footer_columns == 'tow_a_columns' || $locksmith_footer_columns == 'tow_b_columns' || $locksmith_footer_columns == 'tow_c_columns' || $locksmith_footer_columns == 'three_columns') {  ?>
		            <ul class="block large-<?php echo esc_attr($column_tow) ?> medium-<?php echo esc_attr($column_tow) ?> columns animated" data-animated="fadeInRight">
		               <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-2') ) : ?><?php endif; ?>
		            </ul>
						  <?php }  ?>

	            <?php if( $locksmith_footer_columns == 'three_columns' ) {  ?>
		            <ul class="block large-<?php echo esc_attr($column_three) ?> medium-<?php echo esc_attr($column_three) ?> columns animated" data-animated="fadeInRight">
		               <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer-3') ) : ?><?php endif; ?>
		            </ul>
	            <?php }  ?>

		</div>
<?php } ?>
		<footer class="wd-copyright">
			<div class="row">
				<div class="large-12 columns">
						<?php wp_nav_menu( array('theme_location' => 'footer','container_class' => 'copyright-menu', 'fallback_cb' => 'locksmith_main_menu_fallback' )) ?>

				</div>
				<div class="copyright large-12 columns">
					<?php
						 $locksmith_copyright = locksmith_get_option('locksmith_copyright','&copy; 2017 Locksmith All rights reserved.');
					?>
					<p>
						<?php echo html_entity_decode($locksmith_copyright) ?>
					</p>
				</div>
			</div>
		</footer>
	</section>

<?php wp_footer() ?>
</body>
</html>
